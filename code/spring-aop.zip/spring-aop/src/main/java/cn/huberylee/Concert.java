package cn.huberylee;

/**
 * Created by lihui on 16/8/7.
 */
public class Concert implements Performance {
    public void perform() {
        System.out.println("Singing ...");
    }
}
