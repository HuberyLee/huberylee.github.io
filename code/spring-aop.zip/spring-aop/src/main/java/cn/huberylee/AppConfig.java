package cn.huberylee;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Created by lihui on 16/8/6.
 */
@Configuration
@EnableAspectJAutoProxy
public class AppConfig {
    @Bean
    public Concert concert() {
        return new Concert();
    }

    @Bean
    public Audience audience() {
        return new Audience();
    }
}
