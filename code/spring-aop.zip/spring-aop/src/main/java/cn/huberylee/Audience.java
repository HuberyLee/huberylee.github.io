package cn.huberylee;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;

/**
 * Created by lihui on 16/8/6.
 */
@Aspect
public class Audience {

    @Pointcut("execution(* cn.huberylee.Performance.perform(..))")
    public void perform() {}

    @Before("perform()")
    public void takeSeats() {
        System .out.println("Taking seats");
    }

    @Before("perform()")
    public void silenceCellPhones() {
        System.out.println("Silencing cell phones");
    }

    @AfterReturning("perform()")
    public void applause() {
        System.out.println("CLAP CLAP CLAP");
    }

    @AfterThrowing("perform()")
    public void demandRefund() {
        System.out.println("Demanding a refund");
    }

    /*@Around("perform()")
    public void watchPerformance(ProceedingJoinPoint joinPoint) {
        try {
            System.out.println("Taking seats");
            System.out.println("Silencing cell phones");
            joinPoint.proceed();
            System.out.println("CLAP CLAP CLAP");
        } catch (Throwable e) {
            System.out.println("Demanding a refund");
        }
    }*/
}
