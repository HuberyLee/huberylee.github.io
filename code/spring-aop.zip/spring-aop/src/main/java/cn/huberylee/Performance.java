package cn.huberylee;

/**
 * Created by lihui on 16/8/6.
 */
public interface Performance {
    void perform();
}
